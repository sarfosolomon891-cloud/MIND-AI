# MINDAI — starter application

This is the first working foundation for MINDAI: a mobile-friendly AI chat web app with a server-side Gemini API route.

## What is included
- Responsive dark interface
- Chat experience and starter prompts
- Server-side Gemini API integration
- API key kept in an environment variable (not browser code)

## Run locally
1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local`.
4. Add your Gemini API key to `GEMINI_API_KEY` in `.env.local`.
5. Run `npm run dev` and open the local address shown by Next.js.

## Deploy
Deploy the project to a Next.js-compatible host such as Vercel. Add `GEMINI_API_KEY` in the host's project environment variables before deploying. Do not commit `.env.local` or share your API key.

## Important
This is the first MVP foundation, not the complete product. App generation, secure code sandboxing, accounts, database-backed history, billing, and native iOS/Android apps are not implemented yet. Code execution must be isolated in a proper sandbox before offering it to users.
