import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MINDAI — Think Beyond. Build Anything.",
  description: "Your personal AI assistant and creative studio."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
