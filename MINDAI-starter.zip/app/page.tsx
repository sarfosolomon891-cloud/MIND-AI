"use client";

import { useState } from "react";

type Message = { role: "user" | "assistant"; content: string };

const starters = [
  "Help me build a business idea",
  "Explain a difficult topic simply",
  "Write a professional document",
  "Create a website with code"
];

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [prompt, setPrompt] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  async function send(text = prompt) {
    const value = text.trim();
    if (!value || busy) return;
    setNotice("");
    setPrompt("");
    setMessages(prev => [...prev, { role: "user", content: value }]);
    setBusy(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: value })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Something went wrong.");
      setMessages(prev => [...prev, { role: "assistant", content: data.reply }]);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Unable to reach MINDAI.";
      setNotice(msg);
      setMessages(prev => [...prev, {
        role: "assistant",
        content: "I couldn't complete that request. Check your server setup and Gemini API key, then try again."
      }]);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="shell">
      <aside className="sidebar">
        <div className="brand"><span className="brandMark">M</span><span>MINDAI</span></div>
        <button className="newChat" onClick={() => { setMessages([]); setNotice(""); }}>＋ New chat</button>
        <div className="sideLabel">WORKSPACE</div>
        <div className="navItem active">✦ <span>AI Assistant</span></div>
        <div className="navItem">⌘ <span>App Builder <small>Coming next</small></span></div>
        <div className="navItem">▣ <span>My Projects <small>Coming next</small></span></div>
        <div className="navItem">⚙ <span>Settings</span></div>
        <div className="sideFoot">Think Beyond.<br/>Build Anything.</div>
      </aside>

      <section className="main">
        <header className="topbar"><div className="mobileBrand">✦ MINDAI</div><span className="model"><i/> Gemini-powered assistant</span><div className="avatar">S</div></header>
        <div className="conversation">
          {messages.length === 0 ? (
            <div className="welcome">
              <div className="orb">✦</div>
              <p className="eyebrow">YOUR PERSONAL AI WORKSPACE</p>
              <h1>What can I help<br/><em>you create today?</em></h1>
              <p className="sub">Think it. Describe it. Let's build it together.</p>
              <div className="suggestions">{starters.map(item => <button key={item} onClick={() => send(item)}>{item}<span>↗</span></button>)}</div>
            </div>
          ) : (
            <div className="messages">{messages.map((m, i) => <div className={`message ${m.role}`} key={i}><div className="messageIcon">{m.role === "user" ? "S" : "✦"}</div><div className="messageBody"><b>{m.role === "user" ? "You" : "MINDAI"}</b><p>{m.content}</p></div></div>)}{busy && <div className="typing">MINDAI is thinking…</div>}</div>
          )}
        </div>
        {notice && <div className="notice">{notice}</div>}
        <div className="composerWrap">
          <div className="composer"><textarea value={prompt} onChange={e => setPrompt(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} placeholder="Message MINDAI…" rows={1}/><button className="send" onClick={() => send()} disabled={busy || !prompt.trim()} aria-label="Send">↑</button></div>
          <p className="disclaimer">MINDAI can make mistakes. Check important information.</p>
        </div>
      </section>
    </main>
  );
}
