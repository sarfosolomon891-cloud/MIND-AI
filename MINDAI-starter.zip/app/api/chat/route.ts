import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const { message } = await request.json();
    if (!message || typeof message !== "string") {
      return NextResponse.json({ error: "Please enter a message." }, { status: 400 });
    }
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      return NextResponse.json({
        error: "Gemini isn't connected yet. Add GEMINI_API_KEY to your hosting environment variables."
      }, { status: 503 });
    }

    const model = "gemini-2.5-flash";
    const result = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          system_instruction: {
            parts: [{ text: "You are MINDAI, a helpful, honest, capable personal AI assistant. Be clear and practical. When asked to create software, explain assumptions and provide secure, runnable code. Never claim to have deployed or executed something unless that actually happened." }]
          },
          contents: [{ role: "user", parts: [{ text: message }] }],
          generationConfig: { temperature: 0.7, maxOutputTokens: 2048 }
        })
      }
    );
    const data = await result.json();
    if (!result.ok) {
      return NextResponse.json({ error: data?.error?.message || "Gemini request failed." }, { status: result.status });
    }
    const reply = data?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text || "").join("") || "I couldn't generate a response.";
    return NextResponse.json({ reply });
  } catch {
    return NextResponse.json({ error: "Invalid request or server error." }, { status: 500 });
  }
}
